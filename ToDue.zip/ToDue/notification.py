import time
from plyer import notification

def notif(title, message):
    notification.notify(
    title= title,
    message= message,
    app_icon= "C:\\Users\\jayson\\Documents\\CpE - 2103\\Thalita-Torres-Office-Documents.ico",
    timeout=2,
    )
		
if __name__ == '__main__':
    while True:
        notif("Deadline is Near!","There're tasks needed to be done.")
        time.sleep(6)
