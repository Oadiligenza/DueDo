from django.shortcuts import render, redirect
from django.contrib import messages

# Create your views here.

from .models import *
from .forms import *

def listTask(request):
	tasks = task.objects.order_by('complete','due')
	form = TaskForm()
	if request.method =='POST':
		form = TaskForm(request.POST)
		if form.is_valid():
			form.save()
		return redirect('/')

	context = {
		'tasks':tasks,
		'form':form,
		}
	return render(request, 'list_task.html', context)

def updateTask(request, pk):
	tasks = task.objects.get(id=pk)
	form = UpdateForm(instance=tasks)
	if request.method == 'POST':
	    form = UpdateForm(request.POST, instance=tasks)
	    if form.is_valid():
                form.save()
                return redirect('/')

	context = {
		'form':form
		}

	return render(request, 'update_task.html', context)

def deleteTask(request, pk):
	tasks = task.objects.get(id=pk)
	if request.method == 'POST':
		tasks.delete()
		return redirect('/')

	context = {
		'item':tasks
		}
	return render(request, 'delete_task.html', context)

